
package com.porvenir.appmovil.seguridad.dto;


import lombok.Data;

@Data
public class StatusDatosAfiliado {

    public Integer statusCode;
    public String statusDesc;

}
