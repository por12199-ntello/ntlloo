package com.porvenir.appmovil.seguridad.controller;

public class Suma {
	
	public Integer suma(int a, int b) {
	
		return a+b;
	}
	
	
	public Integer resta(int a, int b) {
		
		return a-b;
	}

	
	public Integer multiplicacion(int a, int b) {
		
		return a*b;

	}
	
	public Integer division(int a, int b) {
		
		return a/b;
	}
	
	public Integer suma2(int a, int b) {
		
		return a+b;
	}
	
	public Integer resta2(int a, int b) {
		
		return a-b;
	}

	
	public Integer division2(int a, int b) {
		
		return a/b;
	}
	
	public Integer suma3(int a, int b) {
		
		return a+b;
	}
	
	public Integer resta3(int a, int b) {
		
		return a-b;
	}

}
