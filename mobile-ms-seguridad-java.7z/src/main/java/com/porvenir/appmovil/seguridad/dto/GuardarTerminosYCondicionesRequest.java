package com.porvenir.appmovil.seguridad.dto;

import java.util.List;

import lombok.Data;

@Data
public class GuardarTerminosYCondicionesRequest {
	
	private List<Aceptaciones> aceptaciones = null;

}
