package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class ValidationJWT {

	private Dispositivo dispositivo = new Dispositivo();
	private String jwt;
}
