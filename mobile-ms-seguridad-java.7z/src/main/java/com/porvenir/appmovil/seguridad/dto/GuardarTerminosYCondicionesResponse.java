package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class GuardarTerminosYCondicionesResponse {
	
	private StatusTerminosYCondicionesResponse status;

}
