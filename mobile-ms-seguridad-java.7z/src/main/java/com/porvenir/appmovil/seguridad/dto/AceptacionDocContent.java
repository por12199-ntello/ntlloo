package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class AceptacionDocContent {
	
    private Integer aceptacionTransaccionId;
    private String codigoReferencia;
    private String fechaAceptacion;
    private String ip;
    private Integer numeroIdAfil;
    private String respuesta;
    private String tipoDocumento;
    private String transaccion;
    private Integer version;



}
