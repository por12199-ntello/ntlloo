
package com.porvenir.appmovil.seguridad.dto;



import lombok.Data;

@Data
public class ContentDatosAfiliado {

    public String barrio;
    public Long celular;
    public String ciudad;
    public String departamento;
    public String deptoCiudad;
    public String direccion;
    public String documento;
    public String edad;
    public String email;
    public String envioEmail;
    public String envioSMS;
    public String fechaExp;
    public String fechaNac;
    public String fechaProxActualiza;
    public String fechaUltActualiza;
    public String genero;
    public String idCelular;
    public String idDireccion;
    public String idEMail;
    public String idTelefonoFijo;
    public String lugarExp;
    public String nombre;
    public String pais;
    public String primerApellido;
    public String primerNombre;
    public String segundaCiudad;
    public String segundaDireccion;
    public String segundaIdDireccion;
    public String segundoApellido;
    public String segundoBarrio;
    public String segundoEmail;
    public String segundoIdEMail;
    public String segundoNombre;
    public Long telefonoFijo;
    public String tipoEnvioFisico;
    public String tipoIdentificacion;
    public String tipoMensajeEmail;

}
