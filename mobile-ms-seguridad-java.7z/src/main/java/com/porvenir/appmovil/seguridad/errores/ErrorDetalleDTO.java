package com.porvenir.appmovil.seguridad.errores;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorDetalleDTO {

	private String detalle;
		
}

