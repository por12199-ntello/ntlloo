package com.porvenir.appmovil.seguridad.model;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
/**
* Clase encargada de representar la entidad SEG_COMPONENTE
* @since 1.0
*/

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SEG_COMPONENTE", schema= "GCSEGURIDAD")
@NamedQuery(name = "Componente.findAll", query = "SELECT a FROM Componente a")
public class Componente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "COMPONENTE_ID")
	private Integer idComponente;
	
	
	@Column(name = "NOMBRE")
	private String nombre;
	
	@Column(name = "TIPO")
	private String tipo;
	
	@Column(name = "ACTIVO")
	private String activo;
	
	
	@Column(name = "DESCRIPCION")
	private String descripcion;
	
	@Column(name = "USUARIO_CREACION")
	private String usuarioCreacion;
		
	@Column(name = "FECHA_CREACION")
	private LocalDate fechaCreacion;
		
	@Column(name = "USUARIO_ULTIMA_MODIFICACION")
	private String usuarioUltimaModificacion;
	
	@Column(name = "FECHA_ULTIMA_MODIFICACION")
	private LocalDate fechaUltimaModificacion;


}
