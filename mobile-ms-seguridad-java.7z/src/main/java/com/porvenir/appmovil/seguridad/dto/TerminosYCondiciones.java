
package com.porvenir.appmovil.seguridad.dto;

import java.util.List;

import lombok.Data;

@Data
public class TerminosYCondiciones {

    private List<ListaDocumento> listaDocumentos = null;
    private Status status;
    
    }
