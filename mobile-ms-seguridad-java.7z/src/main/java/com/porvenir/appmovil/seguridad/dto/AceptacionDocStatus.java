package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class AceptacionDocStatus {

		private Integer statusCode;
	    private String statusDesc;
	    

	
}
