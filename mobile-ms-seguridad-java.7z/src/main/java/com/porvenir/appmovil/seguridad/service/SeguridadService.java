package com.porvenir.appmovil.seguridad.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.http.ResponseEntity;

import com.porvenir.appmovil.seguridad.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.appmovil.seguridad.model.Componente;

public interface SeguridadService {

	public ArrayList<Componente> consultarPermisos();

	
	public ResponseEntity<Object> cambioClaveOlvido(String identificacionApp, String tipoIdentificacion, String newPasswordApp, String nombreDispositivo, String serialDispositivo, String ipaddr, String fecha) throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException, KeyManagementException, NoSuchProviderException;
	
	public ResponseEntity<Object> cambioClaveVoluntario(String identificacionApp, String tipoIdentificacion, String oldPasswordApp, String newPasswordApp, String nombreDispositivo, String serialDispositivo, String ipaddr, String fecha) throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException, KeyManagementException, NoSuchProviderException;
	
	public ResponseEntity<Object> terminos(String serviceTransaction, String serviceID, String headerRQ, String userID, String tipoDocumento, String codigoReferencia, String funcionalidad, String producto) throws KeyManagementException, NoSuchAlgorithmException, IOException;
	
	public ResponseEntity<Object> guardarTerminos(String serviceTransaction, String serviceID, String headerRQ, GuardarTerminosYCondicionesRequest entrada) throws KeyManagementException, NoSuchAlgorithmException, IOException;

	public String enviarOTP(String tipoIdentificacion, String numeroIdentificacion);
	
	public String verificarOTP(String tipoIdentificacion, String numeroIdentificacion, String verification);
	
	public ResponseEntity<Object> consultarUltimoDoc(String serviceTransaction,String headerRQ, String serviceID, String codigoReferencia, String funcionalidad, String nombreReferencia, String numeroIdAfil, String producto, String tipoDocumento, String tipoIdAfil)  throws KeyManagementException, NoSuchAlgorithmException;


}
