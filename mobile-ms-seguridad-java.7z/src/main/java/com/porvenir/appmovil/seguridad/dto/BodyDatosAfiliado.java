package com.porvenir.appmovil.seguridad.dto;

import lombok.Data;

@Data
public class BodyDatosAfiliado {
	
	public StatusDatosAfiliado status;
	public ContentDatosAfiliado afiliado;

}
