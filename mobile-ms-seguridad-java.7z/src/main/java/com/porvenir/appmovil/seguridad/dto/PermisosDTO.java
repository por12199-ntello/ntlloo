package com.porvenir.appmovil.seguridad.dto;
import java.util.ArrayList;

import com.porvenir.appmovil.seguridad.model.Componente;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PermisosDTO {
	
	public ArrayList<Componente> listaPermisos;

	

}
