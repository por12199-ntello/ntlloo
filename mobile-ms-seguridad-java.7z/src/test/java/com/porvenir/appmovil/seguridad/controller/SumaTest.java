package com.porvenir.appmovil.seguridad.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;



public class SumaTest {


	@InjectMocks
	Suma suma;
	
	@BeforeEach
	public void setUp()throws Exception {
        MockitoAnnotations.initMocks(this);
    }

	
	@Test
	void testMultiplicacion() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.multiplicacion(a, b);
		
		assertEquals(total, 25);
		
		
	}
	
	
	@Test
	void testDivision() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.division(a, b);
		
		assertEquals(total, 1);
		
		
	}
	
	@Test
	void testSuma2() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.suma2(a, b);
		
		assertEquals(total, 10);
		
		
	}

	@Test
	void testResta2() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.resta2(a, b);
		
		assertEquals(total, 0);
		
		
	}

	
	@Test
	void testDivision2() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.division2(a, b);
		
		assertEquals(total, 1);
		
		
	}
	
	@Test
	void testSuma3() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.suma3(a, b);
		
		assertEquals(total, 10);
		
		
	}

	@Test
	void testResta3() {
		
		int a = 5;
		int b = 5;
		
	//	Mockito.when(suma.suma(a, b)).thenReturn(700);
		
		Integer total = suma.resta3(a, b);
		
		assertEquals(total, 0);
		
		
	}

	
}
