import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Main {

	public static void main(String[] args)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, InvalidKeySpecException,
			IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, InvalidKeyException {
		
		//Primero se genera un par de llaves publicas y llaves privadas.
		KeyPair keyPair = getKeyPair();
		//Se obtiene la llave publica
		
		PublicKey publicKey = getPublicKey(keyPair);
		//Se obtiene la llave privada
		PrivateKey privateKey = getPrivateKey(keyPair);
		
		System.out.println(privateKey+"<--------------PRK");
		//Se obtiene la llave publica en bytes
		byte[] publicKeyBytes = getPublicKeyBytes(publicKey);
		
		System.out.println(publicKeyBytes);
		
		int initiator = 0;
		while (initiator == 0) {
			clearScreen();
			System.out.println("Ejemplo de encripcion con RSA:");
			System.out.println("Seleccione las opciones y presione enter:");
			System.out.println("1: Encripcion");
			System.out.println("2: Desencripcion");
			System.out.println("3: Salir");
			Scanner keyboard = new Scanner(System.in);

			int myint = keyboard.nextInt();

			switch (myint) {
			case 1:
				clearScreen();
				System.out.println("Coloque la clave a encriptar y presione enter: ");
				String pass = keyboard.next();
				if (!pass.isEmpty()) {
					System.out.println("Esta es su clave: " + pass);
					KeyFactory keyFactory = KeyFactory.getInstance("RSA");
					//Se genera la llave publica en formato X509
					EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
					keyFactory.generatePublic(publicKeySpec);
					
	
					Cipher encryptCipher = Cipher.getInstance("RSA");
					encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);

					byte[] secretMessageBytes = pass.getBytes(StandardCharsets.UTF_8);
					//Se encripta con la clave RSA(llave publica)
					byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);
					
					//Se codifica el mensaje en base64 para poder transferirlo.
		
					String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);
					System.out.println("Mensaje Encriptado: " + encodedMessage+" hola");
				} else {
					System.out.println("Favor coloque una clave valida!");
				}
				break;
			case 2:
				clearScreen();
				System.out.println("Coloque el hash a desencriptar y presione enter: ");

				String hashToDecrypt = keyboard.next();
				if (!hashToDecrypt.isEmpty()) {
					
				  System.out.println(hashToDecrypt);
					//Se decodifica en base 64 para obtener los bytes del hash
					byte[] decodedMessage = Base64.getDecoder().decode(hashToDecrypt);
					Cipher decryptCipher = Cipher.getInstance("RSA");

					decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
					
					//Se desencripta el mensaje con la llave privada.
					byte[] decryptedMessageBytes = decryptCipher.doFinal(decodedMessage);
					
					String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);
					System.out.println("Mensaje Desencriptado: " + decryptedMessage);
				} else {
					System.out.println("Favor coloque un hash valido!");
				}

				break;
			case 3:
				clearScreen();
				initiator++;
				System.out.println("Adios!");
				break;
			default:
				break;
			}

		}

	}

	private static void clearScreen() {
		for (int i = 0; i < 5; ++i)
			System.out.println();
	}
	
	//Obtiene las llaves publicas y privadas para realizar la encripcion y desencripcion
	private static KeyPair getKeyPair() throws NoSuchAlgorithmException, FileNotFoundException, IOException {
		KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
		generator.initialize(2048);
		return generator.generateKeyPair();
	}
	
	//Obtiene la llave publica del par de llaves
	private static PublicKey getPublicKey(KeyPair keyPair)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException {
		return keyPair.getPublic();
	}
	
	//Obtiene la llave privada del par de llaves
	private static PrivateKey getPrivateKey(KeyPair keyPair)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException {
		return keyPair.getPrivate();
	}
	
	//Obtiene la llave publica en formato bytes
	private static byte[] getPublicKeyBytes(PublicKey publicKey)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException {

		try (FileOutputStream fos = new FileOutputStream("public.key")) {
			fos.write(publicKey.getEncoded());
		}

		File publicKeyFile = new File("public.key");

		return Files.readAllBytes(publicKeyFile.toPath());
	}

}
