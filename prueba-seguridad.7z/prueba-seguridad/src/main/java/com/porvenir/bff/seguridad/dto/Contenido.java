package com.porvenir.bff.seguridad.dto;

import lombok.Data;

@Data
public class Contenido {
  
  String nombreDispositivo;
  String serialDispositivo;
  String pasApp;
  String identificacionApp;
  String tipoIdentificacionApp;

}
