package com.porvenir.bff.seguridad.serviceImpl;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.stereotype.Service;

import com.porvenir.bff.seguridad.dto.Contenido;
import com.porvenir.bff.seguridad.service.SeguridadService;

@Service
public class SeguridadServiceImpl implements SeguridadService {

  @Override
  public Contenido encriptar(Contenido contenido) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
    
    Contenido cont = new Contenido();
    
    String pasApp = contenido.getPasApp();
    String identificacionApp = contenido.getIdentificacionApp();
    String tipoIdentificacionApp = contenido.getTipoIdentificacionApp();
    String nombreDispositivo = contenido.getNombreDispositivo();
    String serialDispositivo = contenido.getSerialDispositivo();
    
    InputStream inputStream = getClass().getResourceAsStream("/public3.key");
    byte[] publicKeyBytes = inputStream.readAllBytes();

    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
    EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
    PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
    
    Cipher encryptCipher = Cipher.getInstance("RSA");
    encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);

    byte[] secretPasAppBytes = pasApp.getBytes(StandardCharsets.UTF_8);
    byte[] encryptedMessageBytes = encryptCipher.doFinal(secretPasAppBytes);
    String encodedPasApp = Base64.getEncoder().encodeToString(encryptedMessageBytes);

    byte[] secretIdentificacionAppBytes = identificacionApp.getBytes(StandardCharsets.UTF_8);
    byte[] encryptedIdentificacionAppBytes = encryptCipher.doFinal(secretIdentificacionAppBytes);
    String encodedIdentificacionApp = Base64.getEncoder().encodeToString(encryptedIdentificacionAppBytes);

    byte[] secretTipoIdentificacionAppBytes = tipoIdentificacionApp.getBytes(StandardCharsets.UTF_8);
    byte[] encryptedTipoIdentificacionAppBytes = encryptCipher.doFinal(secretTipoIdentificacionAppBytes);
    String encodedTipoIdentificacionApp = Base64.getEncoder().encodeToString(encryptedTipoIdentificacionAppBytes);

    
    cont.setNombreDispositivo(nombreDispositivo);
    cont.setSerialDispositivo(serialDispositivo);
    cont.setPasApp(encodedPasApp);
    cont.setIdentificacionApp(encodedIdentificacionApp);
    cont.setTipoIdentificacionApp(encodedTipoIdentificacionApp);
    
    return cont;
    
    
  }

  @Override
  public Contenido desencriptar(Contenido contenido) throws IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
   
    Contenido cont = new Contenido();
    
    String pasApp = contenido.getPasApp();
    String identificacionApp = contenido.getIdentificacionApp();
    String tipoIdentificacionApp = contenido.getTipoIdentificacionApp();
    String nombreDispositivo = contenido.getNombreDispositivo();
    String serialDispositivo = contenido.getSerialDispositivo();
    
    
    InputStream inputStream = getClass().getResourceAsStream("/private3.key");

    
    byte[] keyBytes = inputStream.readAllBytes();

    PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
    KeyFactory kf = KeyFactory.getInstance("RSA");
    PrivateKey privateKey = kf.generatePrivate(spec);


    byte[] decodedPasApp = Base64.getDecoder().decode(pasApp);
    byte[] decodedIdentificacionApp = Base64.getDecoder().decode(identificacionApp);
    byte[] decodedTipoIdentificacionApp = Base64.getDecoder().decode(tipoIdentificacionApp);

    Cipher decryptCipherPas = Cipher.getInstance("RSA");
    Cipher decryptCipherIdentificacion = Cipher.getInstance("RSA");
    Cipher decryptCipherTipoIdentificacion = Cipher.getInstance("RSA");

    decryptCipherPas.init(Cipher.DECRYPT_MODE, privateKey);
    decryptCipherIdentificacion.init(Cipher.DECRYPT_MODE, privateKey);
    decryptCipherTipoIdentificacion.init(Cipher.DECRYPT_MODE, privateKey);

    byte[] decryptedPasBytes = decryptCipherPas.doFinal(decodedPasApp);
    byte[] decryptedIdentificacionBytes = decryptCipherIdentificacion.doFinal(decodedIdentificacionApp);
    byte[] decryptedTipoIdentificacionBytes = decryptCipherTipoIdentificacion.doFinal(decodedTipoIdentificacionApp);

    String decryptedPas = new String(decryptedPasBytes, StandardCharsets.UTF_8);
    String decryptedIdentificacion = new String(decryptedIdentificacionBytes, StandardCharsets.UTF_8);
    String decryptedTipoIdentificacion = new String(decryptedTipoIdentificacionBytes, StandardCharsets.UTF_8);
      
    
    cont.setNombreDispositivo(nombreDispositivo);
    cont.setSerialDispositivo(serialDispositivo);
    cont.setPasApp(decryptedPas);
    cont.setIdentificacionApp(decryptedIdentificacion);
    cont.setTipoIdentificacionApp(decryptedTipoIdentificacion);
    
    return cont;
    
  }

  @Override
  public String prueba(String prueba) {
    System.out.println(prueba);
    String obt = prueba;
    String resp = "DISPOSITIVO_NO_REGISTRADO"; 
    
    if(obt.equalsIgnoreCase(resp)) {
      return "Correcto";
    }
    
    return "Incorrecto";
    
  }
  
  @Override
  public String limpieza(String prueba) {
    return prueba;
    
    
    
  }

}
