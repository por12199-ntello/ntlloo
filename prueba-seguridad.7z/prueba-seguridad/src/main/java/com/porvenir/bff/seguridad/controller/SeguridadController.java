package com.porvenir.bff.seguridad.controller;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.porvenir.bff.seguridad.dto.Contenido;
import com.porvenir.bff.seguridad.service.SeguridadService;

@RestController
@RequestMapping("/seguridad")
public class SeguridadController {
  
  @Autowired
  SeguridadService seguridadService;
  
  @GetMapping("/encriptar")
  public Contenido encriptar(@RequestBody Contenido contenido) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
    return seguridadService.encriptar(contenido);
    
  }
  
  
  @GetMapping("/desencriptar")
  public Contenido desencriptar(@RequestBody Contenido contenido) throws IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
    return seguridadService.desencriptar(contenido);
    
  }
  
  @GetMapping("/consultarLlave")
  public String consultarLlave() throws IOException {

    InputStream inputStream = getClass().getResourceAsStream("/public3.key");
    
    
    byte[] publicKeyBytes = inputStream.readAllBytes();
    String str = Base64.getEncoder().encodeToString(publicKeyBytes);

    return str;
    
    
  }
  

  @GetMapping("/prueba")
  public String prueba(@RequestParam("pueba") String prueba){
    
    return seguridadService.prueba(prueba);

    
    
  }

  @GetMapping("/16342")
  public String limpieza(@RequestParam("pueba") String prueba){
    
    return seguridadService.limpieza(prueba);

    
    
  }
  
  
}
