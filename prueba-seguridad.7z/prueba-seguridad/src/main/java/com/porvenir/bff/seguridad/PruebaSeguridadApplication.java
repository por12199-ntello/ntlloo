package com.porvenir.bff.seguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaSeguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaSeguridadApplication.class, args);
	}

}
