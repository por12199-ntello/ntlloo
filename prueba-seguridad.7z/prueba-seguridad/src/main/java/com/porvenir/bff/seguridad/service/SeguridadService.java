package com.porvenir.bff.seguridad.service;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.porvenir.bff.seguridad.dto.Contenido;

public interface SeguridadService {

  public Contenido encriptar(Contenido contenido) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
  public Contenido desencriptar(Contenido contenido) throws IOException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException;
  public String prueba(String prueba);
  public String limpieza (String prueba);
}
