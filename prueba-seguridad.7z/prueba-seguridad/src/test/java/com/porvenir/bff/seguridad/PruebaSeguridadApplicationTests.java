package com.porvenir.bff.seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaSeguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
