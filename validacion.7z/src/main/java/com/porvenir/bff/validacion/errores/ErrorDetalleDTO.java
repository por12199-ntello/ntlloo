package com.porvenir.bff.validacion.errores;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorDetalleDTO {

	private String detalle;
		
}

