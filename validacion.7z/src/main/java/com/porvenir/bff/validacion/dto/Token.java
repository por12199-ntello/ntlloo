package com.porvenir.bff.validacion.dto;

import lombok.Data;

@Data
public class Token {
  
  private String token;

}
