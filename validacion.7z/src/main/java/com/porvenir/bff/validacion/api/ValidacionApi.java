package com.porvenir.bff.validacion.api;




import com.porvenir.bff.validacion.dto.AceptacionDoc;
import com.porvenir.bff.validacion.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.bff.validacion.dto.GuardarTerminosYCondicionesResponse;
import com.porvenir.bff.validacion.dto.MicrosoftToken;
import com.porvenir.bff.validacion.dto.TerminosYCondiciones;
import com.porvenir.bff.validacion.dto.ValidationJWT;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ValidacionApi {

	

	@FormUrlEncoded
	@POST("{tenantId}/oauth2/token")
	public Call<MicrosoftToken> responseMicrosoft(@Field("client_id") String client_id,
			@Field("grant_type") String grant_type,
			@Field("resource")String resource,
			@Field("client_secret")String client_secret,
			@Field("username")String username,
			@Field("password")String password,
			@Field("Host")String Host,
			@Field("scope")String scope,
			@Path("tenantId")String tenantId);
	
  
	@POST("porvenir-servicios-sds-app-movil/directorioactivo/iniciarSesion")
	public Call<Object> responseJWTValidation(@Header("headerRq") String headerRq,
													@Body ValidationJWT cuerpo);

	

	@POST("porvenir-servicios-sds-app-movil/directorioactivo/dispositivo")
	public Call<Void> responseJWTEnrolamiento(@Header("headerRq") String headerRq,
													@Body ValidationJWT cuerpo);

	@GET("terminosYCondiciones/canales/v1/consultarDocumento")
	public Call<TerminosYCondiciones> responseTerminosYCondiciones(@Header("serviceTransaction") String serviceTransaction,
																	@Header("headerRQ") String headerRQ,
																	@Header("serviceID") String serviceID,
																	@Header("userID") String userID,
																	@Query("tipoDocumento") String tipoDocumento,
																	@Query("codigoReferencia") String codigoReferencia,
																	@Query("funcionalidad") String funcionalidad,
																	@Query("producto") String producto);
	
	@POST("wsGestionDocumentosWeb/canales/v1/GestionDocumentos/guardarAceptacionDocumento")
	public Call<GuardarTerminosYCondicionesResponse> responseGuardarTerminosYCondiciones(@Header("serviceTransaction") String serviceTransaction,
                                  @Header("headerRQ") String headerRQ,
                                  @Header("serviceID") String serviceID,
                                  @Body GuardarTerminosYCondicionesRequest entrada);
	
	@GET("wsGestionDocumentosWeb/canales/v1/GestionDocumentos/consultarUltimoDocAfiliado")
	public Call<AceptacionDoc> consultarUltimoDoc(
			@Header("serviceTransaction") String serviceTransaction,
			@Header("headerRq") String headerRq,
			@Header("serviceID") String serviceID,
			@Query("tipoDocumento") String tipoDocumento,
			@Query("producto") String producto,
			@Query("nombreReferencia") String nombreReferencia,
			@Query("codigoReferencia") String codigoReferencia,
			@Query("funcionalidad") String funcionalidad,
			@Query("tipoIdAfil") String tipoIdAfil,
			@Query("numeroIdAfil") String numeroIdAfil);
	

	
	
}
