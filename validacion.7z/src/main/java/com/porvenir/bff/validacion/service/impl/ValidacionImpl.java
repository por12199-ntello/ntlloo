package com.porvenir.bff.validacion.service.impl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;

import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;

import com.porvenir.bff.validacion.api.ValidacionApi;
import com.porvenir.bff.validacion.config.ValidacionClient;
import com.porvenir.bff.validacion.dto.AceptacionDoc;
import com.porvenir.bff.validacion.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.bff.validacion.dto.GuardarTerminosYCondicionesResponse;
import com.porvenir.bff.validacion.dto.HeaderRqJWT;
import com.porvenir.bff.validacion.dto.LoginResponse;
import com.porvenir.bff.validacion.dto.MicrosoftToken;
import com.porvenir.bff.validacion.dto.ResponseValidationJWT;
import com.porvenir.bff.validacion.dto.TerminosYCondiciones;
import com.porvenir.bff.validacion.dto.ValidationJWT;
import com.porvenir.bff.validacion.errores.ExceptionDeSistema;
import com.porvenir.bff.validacion.model.Consulta;
import com.porvenir.bff.validacion.repository.ItemRepository;
import com.porvenir.bff.validacion.repository.Repository;
import com.porvenir.bff.validacion.service.ValidacionService;
import com.porvenir.bff.validacion.utils.ConstantesValidation;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

@Service
@Slf4j
public class ValidacionImpl implements ValidacionService {

	final String[] headerNameList = { "authorization", "idusuario", "idrequest", "canal", "ipaddr", "fecha" };

	@Autowired
	Repository valiRepository;

	@Autowired
	ItemRepository mongoItemRepo;

	@Value("${application.ingress}")
	private String baseUrl;

	@Value("${application.rsa}")
	private String RSA;

	@Value("${application.oauth.client_secret}")
	private String client_secret;

	@Value("${application.oauth.username}")
	private String username;

	@Value("${application.oauth.password}")
	private String password;

	@Value("${application.oauth.host}")
	private String host;

	@Value("${application.oauth.scope}")
	private String scope;

	@Value("${application.oauth.tenantId}")
	private String tenantId;

	@Value("${application.oauth.client_id}")
	private String client_id;

	@Value("${application.oauth.grant_type}")
	private String grant_type;

	@Value("${application.oauth.resource}")
	private String resource;

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	@Override
	public ResponseEntity<Object> autorizarApi(RequestEntity<String> request)
			throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException,
			IllegalBlockSizeException, BadPaddingException, InvalidKeyException, NoSuchPaddingException {

		// Obtiene param's
		String params = request.getUrl().getQuery();
		log.info(request.getUrl().getQuery());
		log.info("url " + request.getUrl());

		System.out.println("Paso 1");

		String cedula = "";
		String nombre = "";
		String cedulaBody = "";
		String nombreBody = "";

		HttpHeaders headers = request.getHeaders();

		ResponseEntity<Object> responseEntity = null;
		System.out.println("Paso 2");
		// Obtiene Headers
		Map<String, String> headerData = getHeaders(headerNameList, headers);

		System.out.println("Paso 3");

		// Obtiene Body
		String body = request.getBody();
		String[] arregloDatosBody = null;
		System.out.println("Aqui #" + body + "#");

		if (body != null && body != "") {

			String sinLlave1 = body.replace("{", "");
			String sinLlave2 = sinLlave1.replace("}", "");
			String sinEspacios = sinLlave2.replace(" ", "");
			String sinComillas = sinEspacios.replace("\"", "");

			if (sinComillas.contains(",")) {
				arregloDatosBody = sinComillas.split(",");
			}

			if (!sinComillas.contains(",")) {
				sinComillas = sinComillas + ",n:n";
				arregloDatosBody = sinComillas.split(",");
			}

		}

		if (arregloDatosBody != null) {

			for (String arreglo : arregloDatosBody) {

				if (arreglo.contains("numeroIdentificacion")) {

					nombreBody = arreglo.split(":")[0];
					cedulaBody = arreglo.split(":")[1].trim();

					System.out.println("Cedula Body *" + cedulaBody + "*");

					if (cedulaBody.trim().equalsIgnoreCase("numeroIdentificacion")) {
						cedulaBody = arreglo.split(":")[2].trim();

						System.out.println("Cedula Body condicion *" + cedulaBody);

					}

					System.out.println("Cedula #" + cedulaBody + "#");

					if (cedulaBody.length() > 20) {

						String identificacionSinBackSlash = cedulaBody.replace("\\", "");
						String identificacion = identificacionSinBackSlash.trim();

						System.out.println("1234567----> " + identificacion);

						String decryptedIdentificacion = desencriptar(identificacion);

						cedulaBody = decryptedIdentificacion.split("\\+")[0];

						System.out.println("Cedula desencriptada " + cedulaBody);

					}

					if (!cedulaBody.equals(headerData.get(headerNameList[1]))) {

						responseEntity = new ResponseEntity<>("La cedula del body es diferente a la del header",
								HttpStatus.UNAUTHORIZED);
						System.out.println("Paso 16");

						return responseEntity;

					}

				} else {
					nombreBody = "notnull";
					System.out.println("Paso 13");

				}

			}
		}

		int statusCode = 0;
		String result = "";
		// Obtiene el path y lo recorta
		String path = request.getUrl().getPath();
		String pathrecortado = path.replace("/validar", "");

		System.out.println("---> " + baseUrl);
		System.out.println("Paso 4 path recortado " + pathrecortado);

		// Obtener Token de base de datos

		Consulta consulta = valiRepository
				.findByTOKEN(headerData.get(headerNameList[0]))
				.orElse(null);

		
		System.out.println("Paso 5");

		if (consulta == null) {
			log.info("Consulta vacia: ");
			responseEntity = new ResponseEntity<>("Token no valido", HttpStatus.UNAUTHORIZED);
			System.out.println("Paso 6");

			return responseEntity;
			
		} else {
			System.out.println("Paso 7");

			String idUsuario = consulta.getIDENTIFICACION();
			if (idUsuario.equalsIgnoreCase((headerData.get(headerNameList[1])))) {
				System.out.println("Paso 8");

				String redirect = baseUrl + pathrecortado + "?" + params;
				System.out.println("Paso 9 " + redirect);

				if (params == null) {
					System.out.println("Paso 10");

					redirect = baseUrl + pathrecortado;
					params = "";
				}
				System.out.println("Paso 11");

				String[] paramsSpl = params.split("&"); // key=value
				for (String param : paramsSpl) {
					if (param.startsWith("numeroIdentificacion")) {
						System.out.println("Paso 12");

						cedula = param.split("=")[1];
						nombre = param.split("=")[0];
					} else {
						nombre = "notnull";
						System.out.println("Paso 13");

					}
				}

				if (nombre.equals("numeroIdentificacion")) {
					System.out.println("Paso 14");

					if (cedula.equals(headerData.get(headerNameList[1]))) {
						redirect = baseUrl + pathrecortado + "?" + params;
						System.out.println("Paso 15");

						return httppost(redirect, body, result, statusCode, responseEntity, headerData);

					} else {
						responseEntity = new ResponseEntity<>("La cedula del Query es diferente a la del header",
								HttpStatus.UNAUTHORIZED);
						System.out.println("Paso 16");

						return responseEntity;

					}
				} else {
					System.out.println("Paso 17");

					redirect = baseUrl + pathrecortado + "?" + params;

					System.out.println("Paso 18 " + redirect);

					return httppost(redirect, body, result, statusCode, responseEntity, headerData);

				}

			} else {
				System.out.println("Paso 19");

				responseEntity = new ResponseEntity<>("Usuario no tiene token",
						HttpStatus.UNAUTHORIZED);

				return responseEntity;

			}
		}

	}

	public Map<String, String> getHeaders(String[] array, HttpHeaders headers) {
		HashMap<String, String> header = new HashMap<>();
		for (int i = 0; i < array.length; i++) {
			List<String> valor = headers.get(array[i]);
			if (valor != null) {
				header.put(array[i], valor.toString().replace("[", "").replace("]", ""));
			} else {
				log.info("Header null");
			}
		}
		return header;
	}

	public ResponseEntity<Object> httppost(String redirect, String body, String result, int statusCode,
			ResponseEntity<Object> responseEntity, Map<String, String> headerData) throws IOException {
		HttpClient clientPost = HttpClientBuilder.create().build();
		// Redirecciona

		System.out.println("Paso 1");
		HttpPost post = new HttpPost(redirect);

		System.out.println("Paso 2");

		// Agrega Headers
		for (int i = 0; i < headerNameList.length; i++) {
			post.setHeader(headerNameList[i], headerData.get(headerNameList[i]));
		}
		// Agrega Body
		System.out.println("Paso 3");

		if (body == null) {
			StringEntity entity = new StringEntity("{}", ContentType.APPLICATION_JSON);
			post.setEntity(entity);

		} else {

			StringEntity entity = new StringEntity(body, ContentType.APPLICATION_JSON);
			post.setEntity(entity);

		}

		// Ejecuta post
		HttpResponse responsehtp = clientPost.execute(post);
		System.out.println("Paso 5");

		result = EntityUtils.toString(responsehtp.getEntity());
		System.out.println("Paso 6");

		statusCode = responsehtp.getStatusLine().getStatusCode();
		System.out.println("Paso 7");

		responseEntity = new ResponseEntity<>(result, HttpStatus.resolve(statusCode));
		System.out.println("Paso 8");

		return responseEntity;

	}

	@Override
	public ResponseEntity<Object> login(String identificacionApp, String tipoIdentificacionApp, String pasApp,
			String nombreDispositivo, String serialDispositivo, String ipaddr, String fecha, String idusuario)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {

		LoginResponse login = new LoginResponse();

		InputStream inputStream2 = getClass().getResourceAsStream("/private_key_Sds.der");

		try {


			byte[] keyBytesPorvenir = inputStream2.readAllBytes();

			PKCS8EncodedKeySpec specPorvenir = new PKCS8EncodedKeySpec(keyBytesPorvenir);
			KeyFactory kfPorvenir = KeyFactory.getInstance(RSA);
			PrivateKey privateKeyPorvenir = kfPorvenir.generatePrivate(specPorvenir);

			if (!pasApp.isEmpty() && !identificacionApp.isEmpty() && !tipoIdentificacionApp.isEmpty()) {

				// Se decodifica en base 64 para obtener los bytes del hash

				String decryptedIdentificacion = desencriptar(identificacionApp);
				String decryptedPas = desencriptar(pasApp);
				String decryptedTipoIdentificacion = desencriptar(tipoIdentificacionApp);

				
				
				System.out.println("Paso 0");

				String jwt = crearTokenPrivado(decryptedPas, decryptedIdentificacion, decryptedTipoIdentificacion,
						privateKeyPorvenir);

				System.out.println("Paso 0.1");

				ResponseEntity<Object> obj = validarIngreso(jwt, nombreDispositivo, serialDispositivo, ipaddr, fecha, decryptedIdentificacion);

				System.out.println("Paso 0.2");

				if (obj.getBody() instanceof ResponseValidationJWT) {

					ResponseValidationJWT responseValidationJWT = (ResponseValidationJWT) obj.getBody();

					System.out.println("Paso 0.3");

					if (responseValidationJWT.getStatus() == 200) {

						System.out.println("Paso 0.4");

						ResponseEntity<Object> response = obtenerToken(client_id, grant_type, resource, client_secret,
								username, password, host, scope, tenantId);
						MicrosoftToken mic = (MicrosoftToken) response.getBody();

						valiRepository.save(new Consulta(234, decryptedIdentificacion, decryptedTipoIdentificacion,
								mic.getAccess_token(), idusuario, fecha, null, null));

						System.out.println(mic);
						System.out.println("Paso 0.5");

						if (response.getStatusCodeValue() == 200) {

							System.out.println("Paso 0.6");

							login.getStatus().setLogref("200 - OK");
							System.out.println("Paso 0.6.1");
							login.getStatus().setMessage("EXITO");
							System.out.println("Paso 0.6.2");
							login.getToken().setToken(mic.getAccess_token());
							System.out.println("Paso 0.6.3");

						} else {

							System.out.println("Paso 0.7");

							return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
									.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
											.descripcion(ConstantesValidation.TEC0006_DESCRIPCION)
											.agregarDescripcion2("Error al obtener Token").build());

						}

					} else if (responseValidationJWT.getStatus() != 200) {

						System.out.println("Paso 0.8");
						System.out.println("response "+responseValidationJWT);

						String desc = responseValidationJWT.getDesc().replace("\"", "").replace("{", "")
								.replace("}", "").replace("[", "").replace("]", "").replace(":", ",");
						String array[] = desc.split(",");
						login.getStatus().setLogref(array[1]);
						login.getStatus().setMessage(array[3]);
						login.getToken().setToken(null);
						String resp1 = "DISPOSITIVO_NO_REGISTRADO";
						String resp2 = "PASSWORD_EXPIRO";
						String resp3 = "USUARIO_CLAVE_INCORRECTO";
						String resp4 = "USUARIO_CUENTA_BLOQUEADA";
						String resp5 = "USUARIO_NO_EXISTE";
						String resp6 = "USUARIO_SIN_PRODUCTOS";
						String resp7 = "DATOS_INCONSISTENTES_SERVICIO_VALIDA_REGISTRO";
						
						
						
						if (login.getStatus().getLogref().equalsIgnoreCase(resp1)
								|| login.getStatus().getLogref().equalsIgnoreCase(resp2)) {

							ResponseEntity<Object> response = obtenerToken(client_id, grant_type, resource,
									client_secret, username, password, host, scope, tenantId);
							MicrosoftToken mic = (MicrosoftToken) response.getBody();

							
							if (login.getStatus().getLogref().equalsIgnoreCase(resp1)) {	

								login.getStatus().setLogref("409");
								login.getStatus().setMessage("Dispositivo no registrado");
							
							}
							
							if (login.getStatus().getLogref().equalsIgnoreCase(resp2)) {	

								login.getStatus().setLogref("PASSWORD_EXPIRO");
								login.getStatus().setMessage("Password expiro");
							
							}
							
							login.getToken().setToken(mic.getAccess_token());

							valiRepository.save(new Consulta(234, decryptedIdentificacion, decryptedTipoIdentificacion,
									mic.getAccess_token(), idusuario, fecha, null, null));

							return ResponseEntity.ok().body(login);

						} else if (login.getStatus().getLogref().equalsIgnoreCase(resp3)
								|| login.getStatus().getLogref().equalsIgnoreCase(resp4)
								|| login.getStatus().getLogref().equalsIgnoreCase(resp5)
								|| login.getStatus().getLogref().equalsIgnoreCase(resp6)
								|| login.getStatus().getLogref().equalsIgnoreCase(resp7)){
							
							
							return ResponseEntity.status(HttpStatus.CONFLICT).body(login);
							
						} else {

							System.out.println("Paso 0.9");

							return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(login);
						}

					} else {

						System.out.println("Paso 0.9.1");

						return ResponseEntity.badRequest()
								.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.NEG0032)
										.descripcion(ConstantesValidation.NEG0032_DESCRIPTION)
										.httpStatus(HttpStatus.BAD_REQUEST).build());

					}
				} else {

					return obj;

				}

			}

			System.out.println("Paso 0.9.2");

			return ResponseEntity.ok().body(login);

		} catch (Exception e) {

			System.out.println("Paso 0.9.3");

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error G: " + e.getMessage()).build());

		}

		finally {
			safeClose(inputStream2);
		}

	}

	@Override
	public ResponseEntity<Object> enrolamiento(String identificacionApp, String tipoIdentificacionApp, String pasApp,
			String nombreDispositivo, String serialDispositivo, String ipaddr, String fecha)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {

		// EnrolamientoResponse enrolamiento = new EnrolamientoResponse();

		InputStream inputStream2 = getClass().getResourceAsStream("/private_key_Sds.der");

		try {



			byte[] keyBytesPorvenir = inputStream2.readAllBytes();

			PKCS8EncodedKeySpec specPorvenir = new PKCS8EncodedKeySpec(keyBytesPorvenir);
			KeyFactory kfPorvenir = KeyFactory.getInstance(RSA);
			PrivateKey privateKeyPorvenir = kfPorvenir.generatePrivate(specPorvenir);
			System.out.print("paso1");

			if (!pasApp.isEmpty() && !identificacionApp.isEmpty() && !tipoIdentificacionApp.isEmpty()) {
				System.out.print("paso1");
				// Se decodifica en base 64 para obtener los bytes del hash

				String decryptedIdentificacion = desencriptar(identificacionApp);
				String decryptedPas = desencriptar(pasApp);
				String decryptedTipoIdentificacion = desencriptar(tipoIdentificacionApp);

				String jwt = crearTokenPrivado(decryptedPas, decryptedIdentificacion, decryptedTipoIdentificacion,
						privateKeyPorvenir);

				ResponseEntity<Object> obj = validarEnrolamiento(jwt, ipaddr, fecha, nombreDispositivo,
						serialDispositivo, decryptedIdentificacion);

				if (obj.getBody() instanceof ResponseValidationJWT) {

					ResponseValidationJWT responseValidationJWT = (ResponseValidationJWT) obj.getBody();

					if (responseValidationJWT.getStatus() == 200 || responseValidationJWT.getStatus() == 202) {

						return ResponseEntity.ok().body(responseValidationJWT);

					} else {

						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
								.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
										.descripcion(ConstantesValidation.TEC0006_DESCRIPCION).build());

					}
				} else {

					return obj;
				}

			} else {

				return ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.NEG0032)
								.descripcion(ConstantesValidation.NEG0032_DESCRIPTION)
								.httpStatus(HttpStatus.BAD_REQUEST).build());

			}

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e + " 1").build());

		}

		finally {
			safeClose(inputStream2);
		}
	}
	
	@Override
	public String terminos(String serviceTransaction, String serviceID, String headerRQ, String userID,
			String tipoDocumento, String codigoReferencia, String funcionalidad, String producto)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		try {

			Retrofit retrofitInstance = ValidacionClient.retrofitInstance3();
			ValidacionApi ejemploApi = retrofitInstance.create(ValidacionApi.class);

			Call<TerminosYCondiciones> token = ejemploApi.responseTerminosYCondiciones(serviceTransaction, headerRQ,
					serviceID, userID, tipoDocumento, codigoReferencia, funcionalidad, producto);

			Response<TerminosYCondiciones> execute = token.execute();

			TerminosYCondiciones detalle = execute.body();

			if (detalle.getStatus().getStatusCode() != 200) {

				return new Gson().toJson(ResponseEntity.badRequest().body(ExceptionDeSistema.builder().codigo(ConstantesValidation.NEG0032)
						.descripcion(
								ConstantesValidation.NEG0032_DESCRIPTION + " " + detalle.getStatus().getStatusDesc())
						.httpStatus(HttpStatus.BAD_REQUEST).build())).toString();

			}

			String tyc = new Gson().toJson(ResponseEntity.ok().body(detalle).getBody());
			
			
			return tyc;

		} catch (Exception e) {

			return new Gson().toJson(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build())).toString();

		}

	}

	@Override
	public String consultarUltimoDoc(String serviceTransaction, String headerRQ, String serviceID,
			String codigoReferencia, String funcionalidad, String nombreReferencia, String numeroIdAfil,
			String producto, String tipoDocumento, String tipoIdAfil)
			throws KeyManagementException, NoSuchAlgorithmException {

		Retrofit retrofitInstance = ValidacionClient.retrofitInstance3();
		ValidacionApi consultasApi = retrofitInstance.create(ValidacionApi.class);

		Call<AceptacionDoc> callAceptacion = consultasApi.consultarUltimoDoc(serviceTransaction, headerRQ, serviceID,
				tipoDocumento, producto, nombreReferencia, codigoReferencia, funcionalidad, tipoIdAfil, numeroIdAfil);

		try {

			Response<AceptacionDoc> responseAceptacion = callAceptacion.execute();

			AceptacionDoc aceptacionDoc = responseAceptacion.body();

			if (aceptacionDoc.getStatus().getStatusCode() != 200 && aceptacionDoc.getStatus().getStatusCode() != 0) {

				return new Gson().toJson(ResponseEntity.badRequest()
						.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.NEG0032)
								.descripcion(ConstantesValidation.NEG0032_DESCRIPTION + " "
										+ aceptacionDoc.getStatus().getStatusDesc())
								.httpStatus(HttpStatus.BAD_REQUEST).build())).toString();

			}

			String tyc = new Gson().toJson(ResponseEntity.ok().body(aceptacionDoc).getBody());

			
			return tyc;

		} catch (Exception e) {
			return new Gson().toJson(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build())).toString();
		}

	}

	@Override
	public String guardarTerminos(String serviceTransaction, String serviceID, String headerRQ,
			GuardarTerminosYCondicionesRequest entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {
		try {

			// System.out.println(entrada);

			Retrofit retrofitInstance = ValidacionClient.retrofitInstance3();
			ValidacionApi ejemploApi = retrofitInstance.create(ValidacionApi.class);

			Call<GuardarTerminosYCondicionesResponse> call = ejemploApi
					.responseGuardarTerminosYCondiciones(serviceTransaction, headerRQ, serviceID, entrada);

			Response<GuardarTerminosYCondicionesResponse> execute = call.execute();

			GuardarTerminosYCondicionesResponse detalle = execute.body();

			if (detalle.getStatus().getStatusCode() != 200) {

				return new Gson().toJson(ResponseEntity.badRequest().body(ExceptionDeSistema.builder().codigo(ConstantesValidation.NEG0032)
						.descripcion(
								ConstantesValidation.NEG0032_DESCRIPTION + " " + detalle.getStatus().getStatusDesc())
						.httpStatus(HttpStatus.BAD_REQUEST).build())).toString();

			}

			String tyc = new Gson().toJson(ResponseEntity.ok().body(detalle).getBody());
			
						
			return tyc;

		} catch (Exception e) {

			return new Gson().toJson(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build())).toString();

		}
	}


	public static String crearTokenPrivado(String decryptedPas, String decryptedIdentificacion,
			String decryptedTipoIdentificacion, PrivateKey privateKey)

	{

		Map<String, Object> claims = new HashMap<>();
		System.out.print("Paso 1");
		claims.put("identificacion", decryptedIdentificacion);
		System.out.print("Paso 2");
		claims.put("tipoIdentificacion", decryptedTipoIdentificacion);
		System.out.print("Paso 3");
		claims.put("password", decryptedPas);
		System.out.print("Paso 4");
		claims.put("oldPassword", "");
		System.out.print("Paso 5");
		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.RS512, privateKey).compact();
	}

	public ResponseEntity<Object> obtenerToken(String client_id, String grant_type, String resource,
			String client_secret, String username, String password, String host, String scope, String tenantId)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		try {
			Retrofit retrofitInstance = ValidacionClient.retrofitInstance();
			ValidacionApi ejemploApi = retrofitInstance.create(ValidacionApi.class);

			// System.out.println("obtener-------------->" + client_id);

			Call<MicrosoftToken> token = ejemploApi.responseMicrosoft(client_id, grant_type, resource, client_secret,
					username, password, host, scope, tenantId);
			// System.out.println("obtener--------------> " + token.request().url());

			Response<MicrosoftToken> execute = token.execute();
			// System.out.println("obtener--------------> " + execute);

			MicrosoftToken detalle = execute.body();

			// System.out.println("obtener-------------->");

			return ResponseEntity.ok().body(detalle);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION).agregarDescripcion2("Error: " + e)
							.build());

		}
	}

	public ResponseEntity<Object> validarIngreso(String jwt, String nombreDispositivo, String serialDispositivo,
			String ipaddr, String fecha, String numeroIdentificacion) throws KeyManagementException, NoSuchAlgorithmException, IOException {

		System.out.println("validador de ingreso SDS");
		LocalDateTime time = LocalDateTime.now();
		int numero = (int)(Math.random()*100+1);
		String num = Integer.toString(numero);


		System.out.println("nombreDispositivo "+nombreDispositivo);
		System.out.println("serialDispositivo "+serialDispositivo);

		
		System.out.println("num id "+numeroIdentificacion);
		
		String[] numeroIdentificacionSplit = numeroIdentificacion.split("");
		
		String numeroString = time.toString(); 
		
		System.out.println("fecha "+numeroString);
		
		
		String numeroSinGuion = numeroString.replace("-", "");
		String numeroSinT = numeroSinGuion.replace("T", "");
		String numeroSinDosPuntos = numeroSinT.replace(":", "");
		String numeroSinPunto = numeroSinDosPuntos.replace(".", "");
		
		String numeroConY = numeroSinPunto.replace("", "Y");
		String[] numeroDividido = numeroConY.split("Y");
		
		System.out.println("fecha Y "+numeroConY);

		String rquid = numeroDividido[3]+numeroDividido[4]+numeroDividido[5]+numeroDividido[6]+numeroDividido[7]+numeroDividido[8]+numeroDividido[9]+numeroDividido[10]+numeroDividido[11]+numeroDividido[12]+numeroDividido[13]+numeroDividido[14]+numeroIdentificacionSplit[2]+numeroIdentificacionSplit[3]+numeroIdentificacionSplit[4]+num+"1";
		
		
		HeaderRqJWT headerRq = new HeaderRqJWT();
		headerRq.setRqUID(rquid);
		headerRq.setChannelID("ZMA");
		headerRq.setClientID("APP");
		headerRq.setClientName("0");
		headerRq.setSucursalID("0");
		headerRq.setSucursalName("0");
		headerRq.setIpAddr(ipaddr);
		headerRq.setSessKey("0");
		headerRq.setClientDt(fecha);
		headerRq.setUserID("APP-V1");
		headerRq.setLoginID("0");
		headerRq.setRevCode("0");
		headerRq.setRevUID("0");
		headerRq.setRevAuthID("0");

		String serialDis = serialDispositivo.replace("-", "");

		ValidationJWT validation = new ValidationJWT();
		validation.getDispositivo().setNombre(nombreDispositivo);
		validation.getDispositivo().setSerial(serialDis);
		validation.setJwt(jwt);

		// Gson gson2 = new Gson();
		// String validationRqJSON = gson2.toJson(validation);

		Gson gson = new Gson();
		String headerRqJSON = gson.toJson(headerRq);

		System.out.println("Paso 1");

		try {

			Retrofit retrofitInstance = ValidacionClient.retrofitInstance2();
			ValidacionApi ejemploApi = retrofitInstance.create(ValidacionApi.class);

			Call<Object> responseValidation = ejemploApi.responseJWTValidation(headerRqJSON, validation);

			System.out.println("Paso 2");

			Response<Object> execute = responseValidation.execute();

			System.out.println("2.1");

			ResponseValidationJWT responseValidationJWT = new ResponseValidationJWT();
			int status = execute.code();

			if (status == 200) {

				System.out.println("Paso 3");

				responseValidationJWT.setStatus(status);

			} else {
				String responseError = execute.errorBody().string();
				// String strResponseError = (String) responseError;
				System.out.println("Paso 4");

				responseValidationJWT.setStatus(status);
				responseValidationJWT.setDesc(responseError);

			}

			System.out.println("Paso 5");

			return ResponseEntity.ok().body(responseValidationJWT);

		} catch (Exception e) {

			System.out.println("Paso 6");
			System.out.println("Paso 6.1" + e.getMessage());

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error V: " + e.getMessage()).build());
		}
	}


	
	public ResponseEntity<Object> validarEnrolamiento(String jwt, String ipaddr, String fecha, String nombreDispositivo,
			String serialDispositivo, String numeroIdentificacion) throws KeyManagementException, NoSuchAlgorithmException, IOException {

		System.out.println("validador de enrolamiento SDS");
		LocalDateTime time = LocalDateTime.now();
		int numero = (int)(Math.random()*100+1);
		String num = Integer.toString(numero);


		System.out.println("nombreDispositivo "+nombreDispositivo);
		System.out.println("serialDispositivo "+serialDispositivo);
		
		System.out.println("num id "+numeroIdentificacion);
		
		String[] numeroIdentificacionSplit = numeroIdentificacion.split("");
		
		String numeroString = time.toString(); 
		
		System.out.println("fecha "+numeroString);
		
		
		String numeroSinGuion = numeroString.replace("-", "");
		String numeroSinT = numeroSinGuion.replace("T", "");
		String numeroSinDosPuntos = numeroSinT.replace(":", "");
		String numeroSinPunto = numeroSinDosPuntos.replace(".", "");
		
		String numeroConY = numeroSinPunto.replace("", "Y");
		String[] numeroDividido = numeroConY.split("Y");
		
		System.out.println("fecha Y "+numeroConY);

		String rquid = numeroDividido[3]+numeroDividido[4]+numeroDividido[5]+numeroDividido[6]+numeroDividido[7]+numeroDividido[8]+numeroDividido[9]+numeroDividido[10]+numeroDividido[11]+numeroDividido[12]+numeroDividido[13]+numeroDividido[14]+numeroIdentificacionSplit[2]+numeroIdentificacionSplit[3]+numeroIdentificacionSplit[4]+num+"2";
		

		
		HeaderRqJWT headerRq = new HeaderRqJWT();
		headerRq.setRqUID(rquid);
		headerRq.setChannelID("ZMA");
		headerRq.setClientID("APP");
		headerRq.setClientName("0");
		headerRq.setSucursalID("0");
		headerRq.setSucursalName("0");
		headerRq.setIpAddr(ipaddr);
		headerRq.setSessKey("0");
		headerRq.setClientDt(fecha);
		headerRq.setUserID("INTERNET");
		headerRq.setLoginID("0");
		headerRq.setRevCode("0");
		headerRq.setRevUID("0");
		headerRq.setRevAuthID("0");

		String serialDis = serialDispositivo.replace("-", "");

		ValidationJWT validation = new ValidationJWT();
		validation.getDispositivo().setNombre(nombreDispositivo);
		validation.getDispositivo().setSerial(serialDis);
		validation.setJwt(jwt);

		Gson gson = new Gson();
		String headerRqJSON = gson.toJson(headerRq);

		try {

			Retrofit retrofitInstance = ValidacionClient.retrofitInstance2();
			ValidacionApi ejemploApi = retrofitInstance.create(ValidacionApi.class);

			Call<Void> responseValidation = ejemploApi.responseJWTEnrolamiento(headerRqJSON, validation);

			Response<Void> execute = responseValidation.execute();

			ResponseValidationJWT responseValidationJWT = new ResponseValidationJWT();
			int status = execute.code();

			if (status == 200 || status == 202) {

				responseValidationJWT.setStatus(status);

			} else {
				Object responseError = execute.errorBody().string();
				String strResponseError = (String) responseError;

				responseValidationJWT.setStatus(status);
				responseValidationJWT.setDesc(strResponseError);

			}

			return ResponseEntity.ok().body(responseValidationJWT);

		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionDeSistema.builder().codigo(ConstantesValidation.TEC0006)
							.descripcion(ConstantesValidation.TEC0006_DESCRIPCION)
							.agregarDescripcion2("Error: " + e.getMessage() + " 2").build());
		}
	}


	public String desencriptar(String codigo) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException, IOException {

		InputStream inputStream = getClass().getResourceAsStream("/private3.key");

		System.out.println("Entrada a desencriptar " + codigo);
		try {

			byte[] keyBytes = inputStream.readAllBytes();

			PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
			KeyFactory kf = KeyFactory.getInstance(RSA);
			PrivateKey privateKey = kf.generatePrivate(spec);
			System.out.println("q1");
			byte[] decoded = Base64.getDecoder().decode(codigo);

			System.out.println("q2");

			Cipher decryptCipher = Cipher.getInstance(RSA);
			System.out.println("q3");

			decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
			System.out.println("q4");

			byte[] decryptedBytes = decryptCipher.doFinal(decoded);
			System.out.println("q5");

			String decrypted = new String(decryptedBytes, StandardCharsets.UTF_8);
			System.out.println("q6");

			return decrypted;

		} catch (Exception e) {

			return "Error en desencripcion de dato";
		}

		finally {
			safeClose(inputStream);
		}

	}

	public static void safeClose(InputStream inputStream) {

		if (inputStream != null) {

			try {
				inputStream.close();
			} catch (IOException e) {

				e.printStackTrace();

			}
		}

	}

}
