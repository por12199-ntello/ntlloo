
package com.porvenir.bff.validacion.dto;


import lombok.Data;

@Data
public class Status {

    private Integer statusCode;
    private String statusDesc;
 
}
