package com.porvenir.bff.validacion.model;


import java.math.BigInteger;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;


@Data
@Document(collection= "SEG_COMPROBACION")
public class Consulta {

	@Id
	private BigInteger _id;
	private Integer COMPROBACION_ID;
	private String IDENTIFICACION;
	private String TIPO_IDENTIFICACION;
	private String TOKEN;
	private String USUARIO_CREACION;
	private String FECHA_CREACION;
	private String USUARIO_ULTIMA_MODIFICACION;
	private String FECHA_ULTIMA_MODIFICACION;
	
	
	
	
	public Consulta() {
		super();
	}

	public Consulta(Integer cOMPROBACION_ID, String iDENTIFICACION, String tIPO_IDENTIFICACION, String tOKEN,
			String uSUARIO_CREACION, String fECHA_CREACION, String uSUARIO_ULTIMA_MODIFICACION,
			String fECHA_ULTIMA_MODIFICACION) {
		super();
		COMPROBACION_ID = cOMPROBACION_ID;
		IDENTIFICACION = iDENTIFICACION;
		TIPO_IDENTIFICACION = tIPO_IDENTIFICACION;
		TOKEN = tOKEN;
		USUARIO_CREACION = uSUARIO_CREACION;
		FECHA_CREACION = fECHA_CREACION;
		USUARIO_ULTIMA_MODIFICACION = uSUARIO_ULTIMA_MODIFICACION;
		FECHA_ULTIMA_MODIFICACION = fECHA_ULTIMA_MODIFICACION;
	}
	
	
	
	
}
