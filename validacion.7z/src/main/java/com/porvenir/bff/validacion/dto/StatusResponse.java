package com.porvenir.bff.validacion.dto;

import lombok.Data;


@Data
public class StatusResponse {

  private String logref;
  private String message;
  
}
