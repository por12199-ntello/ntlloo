package com.porvenir.bff.validacion.controller;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eventgrid.producer.producer.Producer;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Component
public class DemoInterceptorRecord extends HandlerInterceptorAdapter {

	Producer producer = new Producer();

	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(baos);
	PrintStream old = null;

	public DemoInterceptorRecord() {
		old = System.out;
		System.setOut(ps);

	}

	// preHandle
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		return true;
	}

	// postHandle
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) {

	}

	// aftercompletion
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) {
		System.out.flush();
		System.setOut(old);
		filterOutput(baos.toString());
		old = System.out;
		System.setOut(old);
	}

	private void filterOutput(String out) {
		String[] filter = out.split("Hibernate:");
		String[] result = Stream.of(filter).filter(str -> str.toLowerCase().contains("select") || str.toLowerCase().contains("insert"))
				.collect(Collectors.toSet()).toArray(new String[0]);

		System.out.println(Arrays.toString(result));

		try (FileWriter fw = new FileWriter("cache.txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter outer = new PrintWriter(bw)) {
			for (String string : result) {
				outer.println(string);
			}
		} catch (IOException e) {
			// exception handling left as an exercise for the reader
		}
	}
}