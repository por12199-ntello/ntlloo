
package com.porvenir.bff.validacion.dto;

import java.util.List;

import lombok.Data;

@Data
public class TerminosYCondiciones {

    private List<ListaDocumento> listaDocumentos = null;
    private Status status;
    
    }
