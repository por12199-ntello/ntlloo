package com.porvenir.bff.validacion.dto;

import java.util.List;

import lombok.Data;

@Data
public class GuardarTerminosYCondicionesRequest {
	
	private List<Aceptaciones> aceptaciones = null;

}
