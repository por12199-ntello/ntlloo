package com.porvenir.bff.validacion.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.porvenir.bff.validacion.model.CosmosDocument;


@Repository
public interface ItemRepository extends MongoRepository<CosmosDocument, String>{

}
