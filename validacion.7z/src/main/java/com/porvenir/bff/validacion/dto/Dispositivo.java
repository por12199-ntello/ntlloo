package com.porvenir.bff.validacion.dto;

import lombok.Data;

@Data
public class Dispositivo {

	private String nombre;
	private String serial;
}
