package com.porvenir.bff.validacion.dto;

import lombok.Data;

@Data
public class GuardarTerminosYCondicionesResponse {
	
	private StatusTerminosYCondicionesResponse status;

}
