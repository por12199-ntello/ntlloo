package com.porvenir.bff.validacion.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.porvenir.bff.validacion.dto.GuardarTerminosYCondicionesRequest;
import com.porvenir.bff.validacion.dto.ReqContenido;
import com.porvenir.bff.validacion.service.ValidacionService;



@RestController

public class ValidacionController {
	
	@Value("${application.bus.serviceTransactionTYC}")
	private String serviceTransactionTYC;

	@Value("${application.bus.serviceIDTYC}")
	private String serviceIDTYC;

	@Value("${application.bus.headerRQ}")
	private String headerRQ;

	@Value("${application.bus.userID}")
	private String userID;

	@Value("${application.bus.serviceTransactionTYCGuardar}")
	private String serviceTransactionTYCGuardar;

	@Value("${application.bus.serviceIDTYCGuardar}")
	private String serviceIDTYCGuardar;

	@Value("${application.bus.headerRQGuardar}")
	private String headerRQGuardar;

	@Value("${application.bus.serviceTransactionConsultarUltimoDoc}")
	private String serviceTransactionConsultarUltimoDoc;

	@Value("${application.bus.serviceIdConsultarUltimoDoc}")
	private String serviceIdConsultarUltimoDoc;

	@Value("${application.bus.headerRqConsultarUltimoDoc}")
	private String headerRqConsultarUltimoDoc;
	
	@Autowired
	ValidacionService servicio;


	
	@PostMapping(value = "/validar/**")
	public ResponseEntity<Object> autorizar(RequestEntity<String> request) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {

		return servicio.autorizarApi(request);
	}

	
	
	@PostMapping(path = "/validar/bff/v1/seguridad/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> login(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {
		
		
		return servicio.login(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha, idusuario);
	
	}

	@PostMapping(path = "/validar/bff/v1/seguridad/enrolamiento", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> enrolamiento(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {


		return servicio.enrolamiento(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha);
	}


	@PostMapping("/validar/bff/v1/seguridad/consultarLlave")
	public String consultarLlave(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha) throws IOException {

		InputStream inputStream = getClass().getResourceAsStream("/public3.key");

		try {

			byte[] publicKeyBytes = inputStream.readAllBytes();
			String str = Base64.getEncoder().encodeToString(publicKeyBytes);

			return str;

		} catch (Exception e) {
			return null;
		}

		finally {

			safeClose(inputStream);

		}

	}	

	@PostMapping(path = "/validar/bff/v1/seguridad/terminosYCondiciones", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String terminos(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization", required = false) String authorization,
			@RequestBody Map<String, String> entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {
		
		
		
		return servicio.terminos(serviceTransactionTYC, serviceIDTYC, headerRQ, userID,
				entrada.get("tipoDocumento"), entrada.get("codigoReferencia"), entrada.get("funcionalidad"),
				entrada.get("producto"));
	}

	@PostMapping(path = "/validar/bff/v1/seguridad/guardarTerminosYCondiciones", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String guardarTerminos(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization", required = false) String authorization,
			@RequestBody GuardarTerminosYCondicionesRequest entrada)
			throws KeyManagementException, NoSuchAlgorithmException, IOException {

		return servicio.guardarTerminos(serviceTransactionTYCGuardar, serviceIDTYCGuardar, headerRQGuardar,
				entrada);

	}

	@PostMapping(path = "/validar/bff/v1/seguridad/consultarUltimoDocAfiliado", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String consultarUltimoDocAfiliado(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr", required = false) String ipaddr,
			@RequestHeader(value = "idrequest") String idrequest, @RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestHeader(value = "authorization", required = false) String authorization,
			@RequestBody ReqContenido contenido) throws KeyManagementException, NoSuchAlgorithmException {

		return servicio.consultarUltimoDoc(serviceTransactionConsultarUltimoDoc, headerRqConsultarUltimoDoc,
				serviceIdConsultarUltimoDoc, contenido.getCodigoReferencia(), contenido.getFuncionalidad(),
				contenido.getNombreReferencia(), contenido.getNumeroIdAfil(), contenido.getProducto(),
				contenido.getTipoDocumento(), contenido.getTipoIdAfil());

	}

	
	@PostMapping(path = "/validar/bff/v1/seguridad2/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> login2(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {
		
		
		return servicio.login(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha, idusuario);
	
	}

	@PostMapping(path = "/validar/bff/v1/seguridad2/enrolamiento", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> enrolamiento2(@RequestHeader(value = "canal") String canal,
			@RequestHeader(value = "ipaddr") String ipaddr, @RequestHeader(value = "idrequest") String idrequest,
			@RequestHeader(value = "idusuario", required = false) String idusuario,
			@RequestHeader(value = "fecha") String fecha, @RequestBody Map<String, String> requestContent)
			throws NoSuchAlgorithmException, FileNotFoundException, IOException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException,
			KeyManagementException, NoSuchProviderException {


		return servicio.enrolamiento(requestContent.get("identificacionApp"),
				requestContent.get("tipoIdentificacionApp"), requestContent.get("passwordApp"),
				requestContent.get("nombreDispositivo"), requestContent.get("serialDispositivo"), ipaddr, fecha);
	}


	@PostMapping("/validar/bff/v1/seguridad2/consultarLlave")
	public String consultarLlave2() throws IOException {

		InputStream inputStream = getClass().getResourceAsStream("/public3.key");

		try {

			byte[] publicKeyBytes = inputStream.readAllBytes();
			String str = Base64.getEncoder().encodeToString(publicKeyBytes);

			return str;

		} catch (Exception e) {
			return null;
		}

		finally {

			safeClose(inputStream);

		}

	}	


	
	public static void safeClose(InputStream inputStream) {

		if (inputStream != null) {

			try {
				inputStream.close();
			} catch (IOException e) {

				e.printStackTrace();

			}
		}

	}

	
}
