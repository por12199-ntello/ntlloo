package com.porvenir.bff.validacion.dto;

import lombok.Data;

@Data
public class AceptacionDoc {
	
    private AceptacionDocContent aceptacionDoc;
    private Documento documento;
    private Status status;
  

}
